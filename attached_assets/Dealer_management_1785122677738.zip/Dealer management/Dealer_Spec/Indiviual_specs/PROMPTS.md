# DMS — Replit Prompts (paste in order)

**How to use each step below**
1. **Attach** the listed files to the Replit Agent message (drag them in). `00-nc.md` is attached to *every* step — it's the rules.
2. **Paste** the prompt text.
3. Let it work, **run the app + skim the diff**, then create a **Replit checkpoint**.
4. Move to the next step. One step per message — never paste the whole spec.

> These prompts assume the app already exists (`Automotive-Aura-Journey`) and bring it into conformance with the spec ("review current… reconcile… add missing… fix contradictions"). If you're building fresh, the same prompts build it — just read "reconcile" as "implement".

> Global rule to keep pasting if the agent drifts: *"Obey `00-nc.md` exactly — canonical status codes, state-machine enums, gate types, RBAC modules, agent list. Don't invent alternatives."*

---

## Step 0 — Orientation (paste once, attach `00-nc.md`)
```
This is a multi-tenant automotive Dealer Management System (AURA) for Guyana. The attached 00-nc.md is the NORMATIVE CONTRACT — the single source of truth for status codes, tenant isolation, state machines, gate types, RBAC modules, the agent list, idempotency, and honesty scope. For the rest of this session I will attach one spec section per task; implement/reconcile strictly to that section AND to 00-nc.md. Never invent enums, status codes, or agent behaviors not in 00-nc.md. Acknowledge and wait — do not change code yet.
```

---

## Step 1 — 🔴 P0 security & correctness fixes (do FIRST)
**Attach:** `00-nc.md`, `27-r9.md`
```
Review the current app against the attached 27-r9.md (corrected-design deltas) and fix ALL P0 items now, obeying 00-nc.md:
1. Tenant isolation: dealer-scope EVERY query including the concierge/chat grounding, /audit-logs, and object-storage reads. Cross-tenant foreign row → 404 (never 403); non-member x-dealer-id → 403.
2. Object storage: enforce per-object dealer ACL (no "any signed-in user can read any object").
3. GRA: switch Ghana→Guyana; the vision model EXTRACTS legible fields only, the SERVER computes duty/VAT deterministically from dealer_taxes, and a human gra_filing gate confirms — the model must never invent TIN/VIN/CIF/duty.
4. Remove/har­den the AUTH_BYPASS and x-test-user-email impersonation shortcuts; replace with the audited, read-only-by-default impersonation from 00-nc.md (NC-10).
5. Gate the agent kill-switch at governance level (NC-13), not settings:admin/dashboard:edit.
For each fix, show the file changed and add a test proving the cross-tenant/ACL cases now fail closed.
```

## Step 2 — Data model & state machines
**Attach:** `00-nc.md`, `19-r1.md`, `20-r2.md`
```
Reconcile the Drizzle schema and status enums to the attached 19-r1.md (data model) and 20-r2.md (canonical state machines). Ensure every table, key field, and relation exists; make the enums for lead.phase, deal.stage, vehicle.status (in_transit→available→reserved→booked→delivered→sold — no "allocated"), booking.status, finance_applications.status, invoices.status, service_orders.status, job_cards.status, deliveries.step (exactly 9), dealers.status, and gates.type match 00-nc.md exactly. Add the target-state first-class tables test_drives, service_cases, reviews (NC-8). Generate a migration; do not change values that already match.
```

## Step 3 — Request pipeline, RBAC, tenancy, entitlements
**Attach:** `00-nc.md`, `02-l0.md`, `22-r4.md`
```
Reconcile the Express middleware/request pipeline to attached 02-l0.md and 22-r4.md, obeying 00-nc.md: the ordered pipeline (authn→dealer-resolve→tenant-status→RBAC→ENTITLEMENT gate→idempotency→validation→rate-limit→resource-scoping→handler). Enforce: status codes per NC-1 (incl. 202/423/429), missing-header handling NC-14, entitlement/feature-flag gate after RBAC (INV-ENT-1, 404 when not entitled), Idempotency-Key semantics NC-7, rate-limiting on public endpoints, field-level RBAC (hidden|view|edit), and soft-delete + restore. Add negative tests for cross-tenant (404), non-member header (403), suspended tenant (423), and rate limit (429).
```

## Step 4 — Platform: tenancy & dealer onboarding (Portal A)
**Attach:** `00-nc.md`, `29-P1.md`, `30-P2.md`
```
Reconcile the Platform Console (super-admin control-plane) to attached 29-P1.md and 30-P2.md. Ensure: two-plane separation (/platform/* control-plane, dealer workspace data-plane), the tenant-binding invariants, and dealer ONBOARDING/PROVISIONING as a SAGA (durable per-step markers + compensation; never hold a DB transaction across GCS/SMTP/LOS calls; dealers.status stays provisioning→active on go-live). Seed defaults on create (divisions, dealer_taxes, stage_checklists, roles/permissions, agent registry+kill-switches) and invite the first GM (Clerk JIT). Add a test that a failed provisioning step compensates cleanly.
```

## Step 5 — Platform: lifecycle, entitlements, governance
**Attach:** `00-nc.md`, `31-P3.md`, `32-P4.md`, `33-P5.md`
```
Reconcile dealer lifecycle & governance to attached 31-P3.md, 32-P4.md, 33-P5.md. Implement: per-tenant entitlements/feature-flags (enforced server-side per Step 3), suspend=423-on-writes, offboarding with export + legal-hold/open-gates blockers, agent-policy library + global kill-switch, and audited READ-ONLY-by-default impersonation (writes need elevation; money/gate-resolve/customer-send hard-blocked). Confirm the isolation guarantees & negative-test suite in 33-P5.md pass.
```

## Step 6 — Lead capture (New)
**Attach:** `00-nc.md`, `03-l1.md`, `21-r3.md`
```
Reconcile lead capture to attached 03-l1.md (agents from 21-r3.md). Ensure omnichannel intake (enquiries, Meta/WhatsApp, Gmail IMAP, walk-in), dedup on email+phone (append, not duplicate), timestamp round-robin assignment (A2, deterministic), auto-quote/code on creation (A3, deterministic tax + pdfkit), mandatory Address, combined source+sub-platform, multi Interested Models, and the lead field set. Autonomous writers limited to A1/A6/A16 per 00-nc.md.
```

## Step 7 — Contacted (24h SLA)
**Attach:** `00-nc.md`, `04-l2.md`
```
Reconcile the Contacted stage to attached 04-l2.md: 24h contact SLA (stageEnteredAt), click-to-call (Twilio + stub fallback), call_logs, A6 call-sentiment (autonomous internal write, guardUntrusted, kill-switchable), the 24h/+3d/+3d/+7d cadence → close with reason, and the "call logged" gate to advance.
```

## Step 8 — Engaged (test drive · financing · negotiation)
**Attach:** `00-nc.md`, `05-l3.md`
```
Reconcile the Engaged stage to attached 05-l3.md: test-drive booking via token link with customer+vehicle availability check (A10) + soft-lock on single-unit models, A5 financing-doc pre-fill (allowlist, HITL review), A7 outreach composer (draft → human Approve&Send, never auto-send), quote regenerate/resend, and first-class test_drives entity (NC-8).
```

## Step 9 — Pre-Book (reservation)
**Attach:** `00-nc.md`, `06-l4.md`
```
Reconcile Pre-Book to attached 06-l4.md: reservation fee mandatory (or trusted-customer bypass with comment), create/link Account+Contact (repeat/household/business/merge), set Selected Model, create the desking deal, verbal-commit follow-up → revert if unpaid.
```

## Step 10 — Vehicle Allocated
**Attach:** `00-nc.md`, `07-l5.md`, `16-mA.md`
```
Reconcile Vehicle Allocation to attached 07-l5.md (inventory in 16-mA.md): A11 deterministic VIN allocation on deal commit (NOT a separate gate), VIN(17)+engine validation, vehicle.status→booked soft-lock with holdUntil, recall/damage monitor, race-safe (no double allocation).
```

## Step 11 — Payment & invoicing
**Attach:** `00-nc.md`, `08-l6.md`, `25-r7.md`
```
Reconcile Payment to attached 08-l6.md (integrations in 25-r7.md): below-floor gate (discount>5%), finance_applications + LOS (Demerara live/sandbox), dual invoices (reservation + final) with idempotent payments→receipts, dealer_taxes engine, GYD/USD conversion, negotiated amount, and bounced/over/under-payment handling. No payment gateway (internal ledger).
```

## Step 12 — Pre-Delivery & Delivered
**Attach:** `00-nc.md`, `09-l7.md`, `10-l8.md`
```
Reconcile delivery to attached 09-l7.md and 10-l8.md: the 9-step delivery workflow (as a saga), PDI work order, registration/insurance status, pre-filled handover PDF, signature upload (OCR verify), Expected vs Actual dates, asset creation + service handoff + feedback survey on completion.
```

## Step 13 — Cancellation & Refund
**Attach:** `00-nc.md`, `11-l9.md`
```
Reconcile cancellation/refund to attached 11-l9.md: Cancel Reservation → gates(refund_release) → Manager approve → Finance refund → release vehicle soft-lock + cancel booking, refundable-until-registration rule, retain full history, notifications.
```

## Step 14 — Service (handoff, scheduled, unscheduled, other cases)
**Attach:** `00-nc.md`, `12-l10.md`, `13-l11.md`, `14-l12.md`, `15-l13.md`, `18-mC.md`
```
Reconcile the service domain to the attached l10–l13 and 18-mC.md (parts): intro call within 5 business days; scheduled cadence → Case (service_cases) → manager review gate → Work Order (one active per asset) → appointment → intake checklist → parts (backorder/supersession/on-hold) → quote/approve → repair → outtake → service invoice → pickup → service history; unscheduled triage→claim; other case types (feedback/profile/escalation). Feature-flag the service module.
```

## Step 15 — Import & Logistics + GRA
**Attach:** `00-nc.md`, `17-mB.md`, `26-r8.md`
```
Reconcile Import & Logistics + GRA to attached 17-mB.md (PDF layouts in 26-r8.md): factory orders, freight, dual-currency landed cost, and the Guyana GRA duty flow — server-computed duty from dealer_taxes (EV exclusion), AI extracts legible fields only, human gra_filing gate. Confirms Step 1's GRA fix end-to-end.
```

## Step 16 — Notifications, Email Engine & WhatsApp
**Attach:** `00-nc.md`, `24-r6.md`, `25-r7.md`
```
Reconcile notifications to attached 24-r6.md (integration contracts in 25-r7.md): the trigger→recipient→channel→template→dedupeKey matrix, in-app primary + Email/WhatsApp via the DB-backed outbox with retry/backoff, and WhatsApp opt-out + delivery-failure fallback.
```

## Step 17 — Reports & Dashboards
**Attach:** `00-nc.md`, `23-r5.md`
```
Reconcile reports/dashboards to attached 23-r5.md: the 10 report types with per-persona visibility, the /dashboard/* endpoints computed SERVER-SIDE and dealer-scoped (not client-side aggregation), persona dashboards (Advisor/Manager/Leadership both divisions), and CSV/Excel/PDF export.
```

## Step 18 — AI Agents console & governance
**Attach:** `00-nc.md`, `21-r3.md`
```
Reconcile the AI layer to attached 21-r3.md: the agent catalog exactly as listed (autonomous A1/A6/A16; deterministic A2/A3/A11; HITL/advisory the rest), semantic kill-switch keys, per-run agent_runs audit, guardUntrusted on ALL untrusted text, and ENFORCE MIN_AGENT_CONFIDENCE (below floor → route to human). Ensure no customer-facing message ever auto-sends.
```

## Step 19 — Documents, PDFs & Privacy/DSAR
**Attach:** `00-nc.md`, `26-r8.md`, `28-r10.md`, `42-docs.md`
```
Reconcile documents to attached 26-r8.md + 42-docs.md (PDF templates & checklist) and implement Privacy/DSAR from 28-r10.md: consent capture at web-to-lead + WhatsApp opt-in, per-customer erasure/anonymize/export endpoints with RBAC+audit, and retention windows per data class.
```

## Step 20 — Navigation, personas & role visibility
**Attach:** `00-nc.md`, `01-personas.md`
```
Reconcile the app shell/navigation to attached 01-personas.md: role-adaptive sidebar, each persona's landing page + what they can see/do + scope, and the "land on Daily Briefing/My Day, review-first" model. Merge the redundant "Run Review"/"Workflow" into a single Advance flow and disambiguate the word "Review" (readiness vs approvals vs AI-run) per the audit.
```

## Step 21 — Final validation & acceptance
**Attach:** `00-nc.md`, `40-V3.md`, `38-V1.md`, `41-V4.md`
```
Run an acceptance pass against attached 40-V3.md (system invariants) and 38-V1.md (coverage matrix): write/execute tests for each invariant (tenant isolation, money idempotency, gate-before-irreversible, AI grounding+HITL+confidence-floor, state-machine-only transitions). Produce a pass/fail report. Then list, from 41-V4.md, the open items that still need infra or client decisions (DR/encryption, payment gateway, GRA e-filing, service SLA window, warranty terms) so I know the boundary.
```

---
### Integration references (attach as needed, not their own step)
When a step touches cross-module flow, also attach the relevant one: `34-X1.md` (entity/relationship map), `35-X2.md` (event/state propagation), `36-X3.md` (end-to-end scenarios), `37-X4.md` (failure/recovery), `39-V2.md` (traceability). Use `36-X3.md` when you want the agent to test a full end-to-end scenario.
