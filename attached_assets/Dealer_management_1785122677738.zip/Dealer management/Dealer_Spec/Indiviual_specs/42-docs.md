# Master Document Checklist

| Document | Type | Layer |
| --- | --- | --- |
| Code / Quotation | 🤖 generated & sent | 1, 3 |
| Bank / financial doc | ⬆️ uploaded by customer | 3 |
| Driving license / ID docs | ⬆️ uploaded, no verification | 3+ |
| Reservation Invoice | 🤖 generated & sent | 4, 6 |
| Final Invoice | 🤖 generated & sent | 6 |
| PDI checklist (Work Order) | 🤖 generated | 7 |
| Handover Form | 🤖 pre-filled → ⬆️ signed & scanned | 7, 8 |
| Warranty Document | 🤖 generated → ⬆️ signed | 7, 8 |
| Registration Form / number | ⬆️ / status-tracked (3rd party) | 7, 8 |
| Insurance confirmation | ✅ checklist/status | 7 |
| Refund confirmation | ⬆️ uploaded | 9 |
| Feedback / Survey | 🤖 sent | 8 |
| Case | 🤖 generated | 11, 12, 13 |
| Intake checklist / Outtake list | 🤖 / ⬆️ attached to WO | 11, 12 |
| Service Quotation / Service Invoice | 🤖 generated (same PDF, heading differs) | 11, 12 |
| Service History entry | 🤖 recorded on Asset | 11, 12 |
| Warranty Claim | 🤖 / ⬆️ | 12 |
| GRA Duty Pack | generated (pdfkit; server-computed duty) | mB / r8 |
