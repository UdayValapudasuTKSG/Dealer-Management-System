# AURA / Realm — Styling & UI Components

- aura/index.css — full theme: Tailwind v4 `@theme inline` design tokens (colors, radii, fonts), glass-panel utilities, global styles for the AURA dealer app.
- realm/index.css — same for the Realm super-admin app (light theme).
- aura/ui/, realm/ui/ — all shadcn-style UI components (buttons, cards, selects, dialogs, dropdowns, tables, etc.), Tailwind v4 compatible (Radix CSS vars use var(...) syntax).
- utils.ts — the `cn()` class-merge helper the components depend on.

Requires: Tailwind CSS v4, radix-ui, class-variance-authority, clsx, tailwind-merge, lucide-react.
