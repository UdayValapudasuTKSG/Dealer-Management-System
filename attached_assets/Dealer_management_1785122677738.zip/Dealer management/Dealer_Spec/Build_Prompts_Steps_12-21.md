# DMS — Replit Build Prompts (Steps 12–21)

AURA DMS · CAM Motors & GT Automotive (Guyana). The remaining build/align steps after the demo-critical ones.

**How to use:** for each step, **attach the listed files** to the Replit Agent message, then **paste the prompt**. Run the app, skim the diff, checkpoint, next — **one step per message**. **Always keep `00-nc.md` attached** (the rules everything obeys). Section files live in `Dealer_Spec/Indiviual_specs/`.
If the agent drifts, paste: *"Obey 00-nc.md exactly — canonical status codes, state-machine enums, gate types, RBAC modules, agent list. Don't invent alternatives."*

---

## Step 12 — Pre-Delivery & Delivered
**Attach:** `00-nc.md`, `09-l7.md`, `10-l8.md`
```
Reconcile delivery to attached 09-l7.md and 10-l8.md, obeying 00-nc.md: the 9-step delivery workflow (as a saga), PDI work order, registration/insurance status, pre-filled handover PDF, signature upload (OCR verify), Expected vs Actual delivery dates, and on completion — create the Asset, hand off to a Service Advisor, and fire the feedback survey. Show a delivery advanced end-to-end with the asset created.
```

## Step 13 — Cancellation & Refund
**Attach:** `00-nc.md`, `11-l9.md`
```
Reconcile cancellation/refund to attached 11-l9.md, obeying 00-nc.md: Cancel Reservation → gates(refund_release) → Manager approve → Finance refund → release the vehicle soft-lock + cancel the booking, apply the refundable-until-registration rule, retain full history, and send notifications. Show a cancellation approved, refunded, and the vehicle returned to available.
```

## Step 14 — Service (handoff + scheduled + unscheduled + other cases)
**Attach:** `00-nc.md`, `12-l10.md`, `13-l11.md`, `14-l12.md`, `15-l13.md`, `18-mC.md`
```
Reconcile the service domain to the attached l10–l13 and 18-mC.md (parts), obeying 00-nc.md: intro call within 5 business days; scheduled cadence → Case (service_cases) → manager review gate → Work Order (one active per asset) → appointment → intake checklist → parts (backorder/supersession/on-hold) → quote/approve → repair → outtake → service invoice → pickup → service history; unscheduled triage → claim; other case types (feedback/profile/escalation). Feature-flag the service module. Show one scheduled case run through to a service invoice.
```

## Step 15 — Import & Logistics + GRA
**Attach:** `00-nc.md`, `17-mB.md`, `26-r8.md`, `27-r9.md`
```
Reconcile Import & Logistics + GRA to attached 17-mB.md (PDF layouts in 26-r8.md), applying the 27-r9.md fix, obeying 00-nc.md. GRA = GUYANA Revenue Authority (GYD; VAT 0/14%; import duty; EV exclusion) — NOT Ghana. The vision model EXTRACTS legible fields only; the SERVER computes duty/VAT deterministically from dealer_taxes; a human gra_filing gate confirms before submit — never let the model invent TIN/VIN/CIF/duty. Capture CIF (FOB + freight + insurance) + TIN + engine size/fuel, then generate the GRA Duty Pack PDF. Show one imported vehicle with extracted fields + server-computed duty + generated PDF.
```

## Step 16 — Notifications, Email Engine & WhatsApp
**Attach:** `00-nc.md`, `24-r6.md`, `25-r7.md`
```
Reconcile notifications to attached 24-r6.md (integration contracts in 25-r7.md), obeying 00-nc.md: the trigger → recipient → channel → template → dedupeKey matrix, in-app primary + Email/WhatsApp via the DB-backed outbox with retry/backoff, and WhatsApp opt-out + delivery-failure fallback. Show a trigger (e.g. Invoice Generated) firing an in-app + WhatsApp/email notification with dedupe.
```

## Step 17 — Reports & Dashboards
**Attach:** `00-nc.md`, `23-r5.md`
```
Reconcile reports/dashboards to attached 23-r5.md, obeying 00-nc.md: the 10 report types with per-persona visibility, the /dashboard/* endpoints computed SERVER-SIDE and dealer-scoped (not client-side aggregation), persona dashboards (Advisor / Manager / Leadership across both divisions), and CSV/Excel/PDF export. Show one report per persona rendering from live data.
```

## Step 18 — AI Agents console & governance
**Attach:** `00-nc.md`, `21-r3.md`
```
Reconcile the AI layer to attached 21-r3.md, obeying 00-nc.md: the agent catalog exactly as listed (autonomous A1/A6/A16; deterministic A2/A3/A11; HITL/advisory the rest), semantic kill-switch keys, per-run agent_runs audit, guardUntrusted on ALL untrusted text, and ENFORCE MIN_AGENT_CONFIDENCE (below floor → route to human). Confirm no customer-facing message ever auto-sends. Show the agents console with kill-switch + a run's audit entry.
```

## Step 19 — Documents, PDFs & Privacy/DSAR
**Attach:** `00-nc.md`, `26-r8.md`, `28-r10.md`, `42-docs.md`
```
Reconcile documents to attached 26-r8.md + 42-docs.md (PDF templates & checklist) and implement Privacy/DSAR from 28-r10.md, obeying 00-nc.md: consent capture at web-to-lead + WhatsApp opt-in, per-customer erasure/anonymize/export endpoints with RBAC + audit, and retention windows per data class. Show a generated PDF from a template and a customer data-export.
```

## Step 20 — Navigation, personas & role visibility
**Attach:** `00-nc.md`, `01-personas.md`
```
Reconcile the app shell/navigation to attached 01-personas.md, obeying 00-nc.md: role-adaptive sidebar, each persona's landing page + what they can see/do + scope, and the "land on Daily Briefing/My Day, review-first" model. Merge the redundant "Run Review"/"Workflow" into a single Advance flow and disambiguate the word "Review" (readiness vs approvals vs AI-run). Show two different roles logging in to distinct, correctly-scoped views.
```

## Step 21 — Final validation & acceptance
**Attach:** `00-nc.md`, `40-V3.md`, `38-V1.md`, `41-V4.md`
```
Run an acceptance pass against attached 40-V3.md (system invariants) and 38-V1.md (coverage matrix), obeying 00-nc.md: write/execute tests for each invariant (tenant isolation, money idempotency, gate-before-irreversible, AI grounding + HITL + confidence-floor, state-machine-only transitions) and produce a pass/fail report. Then from 41-V4.md list the open items still needing infra or client decisions (DR/encryption, payment gateway, GRA e-filing, service SLA window, warranty terms) so the boundary is explicit.
```

---
*Companion to DMS_Process_Spec (v3.1). Steps 0–11 (orientation, P0 security fixes, data model, pipeline/RBAC, platform onboarding, lead→payment stages) are in the full prompt set. Attach `00-nc.md` with every step.*
