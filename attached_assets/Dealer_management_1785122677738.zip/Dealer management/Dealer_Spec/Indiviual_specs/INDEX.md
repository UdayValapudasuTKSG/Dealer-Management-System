# DMS Spec — per-section files (for Replit)

Feed Replit **one section file per task** — never the whole spec. Always also attach **`00-nc.md` (§0 Normative Contract)**: it's the rules every module must obey. Drive one module per prompt, verify, then the next.

**Prompt pattern:** _"Implement/‑fix per the attached `NN-<id>.md`, obeying `00-nc.md`. <specific ask>."_

| File | Section | When to give it to Replit |
| --- | --- | --- |
| `00-nc.md` | §0 — Normative Contract Single Source of Truth | ALWAYS — attach with EVERY build/fix task (the rules all code must obey). |
| `01-personas.md` | Personas & Capabilities | Building navigation, dashboards, or role-based access/visibility. |
| `02-l0.md` | Layer 0 — Cross-cutting All personas | Any API work — request pipeline, RBAC, tenancy, idempotency, entitlements. |
| `03-l1.md` | Layer 1 — Lead Capture (New) Sales Advisor | Lead capture / intake / dedup / round-robin. |
| `04-l2.md` | Layer 2 — Contacted (24h SLA) Sales Advisor | Contacted stage / 24h call SLA / click-to-call. |
| `05-l3.md` | Layer 3 — Engaged (test drive · financing · negotiation) Sales Advisor | Engaged: test drive, financing, negotiation. |
| `06-l4.md` | Layer 4 — Pre-Book (Order Confirmed / reservation) Sales Advisor | Pre-Book / reservation / account creation. |
| `07-l5.md` | Layer 5 — Vehicle Allocated Sales Advisor | Vehicle allocation / VIN lock. |
| `08-l6.md` | Layer 6 — Payment (Payment in Progress) Finance / Sales Advisor | Payment / invoicing / finance / LOS. |
| `09-l7.md` | Layer 7 — Pre-Delivery (Ready for Delivery) Delivery Advisor | Pre-delivery / PDI / docs. |
| `10-l8.md` | Layer 8 — Delivered (Closed Won) Delivery Advisor | Delivery / handover / asset creation. |
| `11-l9.md` | Layer 9 — Cancellation & Refund Sales Manager / Finance | Cancellation & refund. |
| `12-l10.md` | Layer 10 — Service handoff & Intro Service Advisor | Service handoff & intro. |
| `13-l11.md` | Layer 11 — Service: Scheduled Service Advisor · Manager · Technician | Scheduled service / cases / work orders. |
| `14-l12.md` | Layer 12 — Service: Unscheduled Service Advisor | Unscheduled service / claims. |
| `15-l13.md` | Layer 13 — Other Case types Service Advisor / Manager | Other case types (feedback/profile/escalation). |
| `16-mA.md` | Module A — Inventory Management Inventory / Sales Manager | Inventory management module. |
| `17-mB.md` | Module B — Import & Logistics + GRA Duty Finance / Customs | Import & Logistics + GRA duty module. |
| `18-mC.md` | Module C — Parts & Supply Chain Parts Advisor | Parts & supply chain module. |
| `19-r1.md` | Reference R1 — Data Model (all ~57 tables) | Building the data model / schema. |
| `20-r2.md` | Reference R2 — State Machines | Any status/lifecycle/state-machine work (canonical enums). |
| `21-r3.md` | Reference R3 — Agent Catalog | Building or governing AI agents. |
| `22-r4.md` | Reference R4 — RBAC & API/Error Conventions | RBAC, permissions, API error codes. |
| `23-r5.md` | Reference R5 — Reports, Dashboards & BI | Reports & dashboards. |
| `24-r6.md` | Reference R6 — Notifications & Comms Matrix | Notifications / email / WhatsApp. |
| `25-r7.md` | Reference R7 — Integration Contracts | External integrations (Meta/Twilio/Gmail/LOS/GCS). |
| `26-r8.md` | Reference R8 — Document & PDF Template Layouts | PDF/document templates. |
| `27-r9.md` | Reference R9 — Corrected-Design Deltas (spec vs built app) | FIXING the built app — the defect→correct-mandate deltas. |
| `28-r10.md` | Reference R10 — Privacy, Retention & Data-Subject Rights | Privacy, retention, data-subject rights (erasure/consent/export). |
| `29-P1.md` | Platform P1 — Two-Portal Architecture & Tenancy Super Admin / Platform | Platform tenancy / isolation. |
| `30-P2.md` | Platform P2 — Dealer Onboarding & Provisioning Super Admin | Dealer onboarding & provisioning. |
| `31-P3.md` | Platform P3 — Dealer Lifecycle, Entitlements & Offboarding Super Admin / Platform Finance | Dealer lifecycle / entitlements / offboarding. |
| `32-P4.md` | Platform P4 — Super-Admin Ops & Cross-Tenant Governance Super Admin | Super-admin governance / impersonation / kill-switch. |
| `33-P5.md` | Platform P5 — Isolation Guarantees & Platform API Index | Platform API index & isolation guarantees. |
| `34-X1.md` | Integration X1 — Entity Ownership & Relationship Map | Entity/relationship map (how tables link). |
| `35-X2.md` | Integration X2 — Cross-Module Event & State Propagation | Cross-module events & state propagation. |
| `36-X3.md` | Integration X3 — End-to-End Scenario Matrix (all situations) | End-to-end scenario testing. |
| `37-X4.md` | Integration X4 — Failure, Concurrency & Recovery Taxonomy | Failure/concurrency/recovery handling. |
| `38-V1.md` | Validation V1 — Coverage Completeness Matrix | QA coverage checklist. |
| `39-V2.md` | Validation V2 — Domain Capability Traceability | Domain→section traceability. |
| `40-V3.md` | Validation V3 — System Invariants & Guarantees | System invariants (acceptance tests). |
| `41-V4.md` | Validation V4 — Open Items & Honest Limits | Open items / what's Phase-2 or needs infra. |
| `42-docs.md` | Master Document Checklist | Wiring document/PDF generation & the artifact checklist. |
| `43-changelog.md` | Changelog | Version history (reference only). |

## Suggested build order
1. `00-nc.md` (read once — the contract) + `*-r1-*` data model + `*-l0-*` pipeline.
2. Platform onboarding: `P1 → P5`.
3. Pipeline: `l1 → l13` (one per prompt).
4. Modules: `mA` inventory, `mB` import/GRA, `mC` parts.
5. References as needed (`r2` state machines, `r3` agents, `r4` RBAC, `r6` notifications, `r7` integrations, `r8` PDFs, `r10` privacy).
6. Fixes: `r9` corrected-design deltas (map to the audit's P0/P1).
7. QA: `V1`–`V4`, integration `X1`–`X4`.
