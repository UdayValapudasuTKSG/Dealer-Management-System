## Personas & Capabilities — what the website shows each role

> Roles per the GT Automotives BRD (12 business roles) + platform Admin/Super-Admin. Two portals: **Dealer Workspace** (all roles below) and **Platform Console** (Super Admin). Enforce on API *and* UI; the client's field-level access matrix overrides these defaults once received.

# Leadership / General Manager Vishok · Aditya
- **Lands on:** Executive Dashboard — company-wide, **both divisions (CAM + GT)**.
- **Website shows:** Consolidated KPIs across Sales/Delivery/Service; CAM vs GT comparison; revenue by model/division, conversion, SLA compliance, channel performance, lost-leads.
- **Can do:** View / drill / export every report & dashboard. **Read-only** across everything (per BRD).
- **Scope:** All data, both divisions.
- **Cannot:** Day-to-day edits or configuration (unless also granted Admin).

# Sales Manager
- **Lands on:** Team Dashboard (division pipeline by advisor + SLA-breach flags).
- **Website shows:** All division leads & advisors, pipeline funnel, SLA dashboard, performance dashboards, team calendar.
- **Can do:** Oversee sales; **approve/reject cancellations**; approve discounts above threshold; manual reassign/override; create Accounts; view team reports.
- **Scope:** All leads in their division + their advisors.
- **Cannot:** Cross-division data (unless Leadership); dealer config (taxes/templates).

# Sales Advisor
- **Lands on:** My Daily Briefing (own leads + today's tasks) — never a raw list.
- **Website shows:** Own leads (New→Vehicle Allocated), Tasks (Call 1st–4th, Send Quotation, Schedule Test Drive, Follow-up on Payment), Calendar, Quotes, Documents, Call logs.
- **Can do:** Create leads; click-to-call; generate/resend Code; schedule test drive; upload docs; capture reservation; allocate VIN; **create Accounts**; close as "Not Interested".
- **Scope:** Own leads only.
- **Cannot:** Configure taxes; delete leads; see other advisors' leads.

# Delivery Advisor
- **Lands on:** Delivery Queue (assigned deliveries).
- **Website shows:** Assigned deliveries, handover/warranty docs, delivery calendar; Tasks (Request Vehicle IDs, Confirm Delivery Date & Time).
- **Can do:** Conduct PDI; enter registration number; generate/print pre-filled handover; upload signed docs; enter Actual Delivery Date.
- **Scope:** Assigned deliveries.
- **Cannot:** Pipeline stages before Pre-Delivery; sales config.

# Service Manager
- **Lands on:** Service Operations Dashboard (active cases, SLA breaches, technician load).
- **Website shows:** All division cases & work orders, appointments, warranty/recall queue, advisor performance.
- **Can do:** **Approve service requests**; review Cases, consult technician, record notes, **authorize Work Orders**; reports.
- **Scope:** Service operations (division).
- **Cannot:** Sales pipeline config.

# Service Advisor
- **Lands on:** Service Dashboard (assigned assets, upcoming cadences, open WOs).
- **Website shows:** Assigned assets/customers, Cases, Work Orders, Service History, service calendar, cadences; Tasks (Book/Confirm Appointment, Update Repair Status, Notify Pickup, Follow-up after service).
- **Can do:** Validate customer info; create/close Cases; open Work Orders; book appointments; intake/outtake checklists; prepare quotations & invoices.
- **Scope:** Assigned assets/customers post-delivery.
- **Cannot:** Sales pipeline stages.

# Technician
- **Lands on:** Workshop — assigned jobs/Work Orders.
- **Website shows:** Assigned Work Orders, diagnosis fields (Concern/Cause/Correction), labor hours, parts consumption.
- **Can do:** Diagnose & repair; update the Work Order; hand vehicle back to Service Advisor.
- **Scope:** Assigned Work Orders.
- **Cannot:** Financials, pipeline, configuration.

# Parts Advisor
- **Lands on:** Parts dashboard (stock, low-stock, on-order).
- **Website shows:** Parts inventory, availability statuses, orders, ROQ, USD/GYD costing.
- **Can do:** Manage parts inventory, availability & ordering for service/repairs; coordinate WO On-Hold when parts unavailable.
- **Scope:** Parts.
- **Cannot:** Sales/pipeline. (Parts = Phase-2-leaning.)

# Finance Manager
- **Lands on:** Finance dashboard.
- **Website shows:** Invoices, payments, reservation vs final payment status, refunds, GRA filing, reservation/final payment summary.
- **Can do:** **Handle all financial activities, including refunds and approvals**; process GRA filings.
- **Scope:** Financial data.
- **Cannot:** Edit pipeline/service operations.

# Marketing Manager & Marketing Coordinator
- **Lands on:** Marketing dashboard.
- **Website shows:** Leads by source/channel, conversion by campaign/source, customer segmentation, vehicle-interest trends, lead-generation overview.
- **Can do:** Manager: oversee marketing, monitor campaigns/performance. Coordinator: support marketing & **campaign execution** (incl. QR campaign forms feeding web-to-lead).
- **Scope:** Marketing / lead-source data.
- **Cannot:** Manager approvals (Coordinator); pipeline/service edits.

# Dealer Admin
- **Lands on:** Admin Console (dealer-scoped).
- **Website shows:** Config: Taxes, Lead Sources, Pipeline/Stage & mandatory-field config, Templates (code/invoice/handover), WhatsApp/Email (Email Engine), Users & Roles, Employee Master/Org, Showrooms, SLA Rules, Service Cadences, AI-agent toggles, Audit Logs.
- **Can do:** All dealer-level configuration.
- **Scope:** Their dealer.
- **Cannot:** Cross-dealer/tenant configuration.

# Super Admin Platform Console
- **Lands on:** Platform Console.
- **Website shows:** Tenants/Dealers, cross-dealer config, platform users, feature flags, agent-policy library, cross-tenant audit — everything.
- **Can do:** Onboard/govern dealers; platform administration across tenants.
- **Scope:** All tenants.
- **Cannot:** —
