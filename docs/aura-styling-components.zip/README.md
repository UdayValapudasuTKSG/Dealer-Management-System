# AURA / Realm — Styling & UI Components

- aura/index.css — full theme: Tailwind v4 `@theme inline` design tokens (colors, radii, fonts), glass-panel utilities, global styles for the AURA dealer app.
- realm/index.css — same for the Realm super-admin app (light theme).
- aura/ui/, realm/ui/ — all shadcn-style UI components (buttons, cards, selects, dialogs, dropdowns, tables, etc.), Tailwind v4 compatible (Radix CSS vars use var(...) syntax).
- utils.ts — the `cn()` class-merge helper the components depend on.

Requires: Tailwind CSS v4, radix-ui, class-variance-authority, clsx, tailwind-merge, lucide-react.

## aura/app-components/
- side-nav.tsx — auto-collapsing sidebar navigation (permission-aware)
- deals.tsx — the pipeline (kanban) board page
- page.tsx / page-hero.tsx — page layout shell + hero header
- view-controls.tsx — grid/list + density toggles
- pagination.tsx — pagination with per-page selector
These reference app hooks (auth, API); strip or replace those imports when reusing.
